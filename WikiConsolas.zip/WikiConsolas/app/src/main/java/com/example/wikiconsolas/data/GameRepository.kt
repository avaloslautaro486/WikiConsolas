package com.example.wikiconsolas.data

import android.content.Context
import com.example.wikiconsolas.model.Game
import org.json.JSONArray
import org.json.JSONObject

object GameRepository {

    fun load(context: Context): List<Game> {
        val text = context.assets.open("games.json").bufferedReader().use { it.readText() }
        val array = JSONArray(text)
        return (0 until array.length()).map { parse(array.getJSONObject(it)) }
    }

    private fun parse(o: JSONObject) = Game(
        id = o.getString("id"),
        title = o.getString("title"),
        developer = o.getString("developer"),
        publisher = o.getString("publisher"),
        releaseDate = o.getString("releaseDate"),
        genre = o.getString("genre"),
        subgenre = o.optString("subgenre"),
        mode = o.optString("mode"),
        universe = o.optString("universe"),
        setting = o.optString("setting"),
        mainCity = o.optString("mainCity"),
        consoles = o.getJSONArray("consoles").toList(),
        otherPlatforms = o.optJSONArray("otherPlatforms")?.toList() ?: emptyList(),
        protagonists = o.getJSONArray("protagonists").toList(),
        synopsis = o.getString("synopsis"),
        cover = o.getString("cover")
    )

    private fun JSONArray.toList(): List<String> =
        (0 until length()).map { getString(it) }
}
