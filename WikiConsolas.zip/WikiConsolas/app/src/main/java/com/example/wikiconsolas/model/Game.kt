package com.example.wikiconsolas.model

data class Game(
    val id: String,
    val title: String,
    val developer: String,
    val publisher: String,
    val releaseDate: String,
    val genre: String,
    val subgenre: String,
    val mode: String,
    val universe: String,
    val setting: String,
    val mainCity: String,
    val consoles: List<String>,
    val otherPlatforms: List<String>,
    val protagonists: List<String>,
    val synopsis: String,
    val cover: String // nombre del archivo en res/drawable, sin extensión
)
