package com.example.wikiconsolas.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.example.wikiconsolas.model.Game

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(game: Game, onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(game.title, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState())
        ) {
            Image(
                painter = coverPainter(game.cover),
                contentDescription = game.title,
                modifier = Modifier
                    .height(320.dp)
                    .align(Alignment.CenterHorizontally)
                    .clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.height(16.dp))

            Section("Ficha técnica") {
                InfoRow("Desarrolladora", game.developer)
                InfoRow("Distribuidora", game.publisher)
                InfoRow("Lanzamiento", game.releaseDate)
                InfoRow("Género", game.genre)
                InfoRow("Subgénero", game.subgenre)
                InfoRow("Modo de juego", game.mode)
                InfoRow("Universo", game.universe)
                InfoRow("Ambientación", game.setting)
                InfoRow("Ciudad principal", game.mainCity)
            }

            Section("Consolas disponibles") {
                game.consoles.forEach { Text("• $it") }
                if (game.otherPlatforms.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text("Otras plataformas:", style = MaterialTheme.typography.labelLarge)
                    game.otherPlatforms.forEach { Text("• $it") }
                }
            }

            Section("Protagonistas") {
                game.protagonists.forEach { Text("• $it") }
            }

            Section("Sinopsis") {
                Text(game.synopsis)
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(6.dp))
    Column(content = content)
    Spacer(Modifier.height(20.dp))
}

@Composable
private fun InfoRow(label: String, value: String) {
    if (value.isBlank()) return
    Row(Modifier.padding(vertical = 2.dp)) {
        Text("$label: ", style = MaterialTheme.typography.labelLarge)
        Text(value)
    }
}
