package com.example.wikiconsolas.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.wikiconsolas.model.Game

@Composable
fun coverPainter(name: String): androidx.compose.ui.graphics.painter.Painter {
    val context = LocalContext.current
    val id = context.resources.getIdentifier(name, "drawable", context.packageName)
    return painterResource(id)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(games: List<Game>, onGameClick: (Game) -> Unit) {
    var query by remember { mutableStateOf("") }
    var selectedConsole by remember { mutableStateOf<String?>(null) }

    val allConsoles = remember(games) { games.flatMap { it.consoles }.distinct() }
    val filtered = games.filter { game ->
        (query.isBlank() || game.title.contains(query, ignoreCase = true)) &&
            (selectedConsole == null || selectedConsole in game.consoles)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Wiki Consolas") }) }
    ) { padding ->
        Column(Modifier.padding(padding).padding(horizontal = 16.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar juego") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(allConsoles) { console ->
                    FilterChip(
                        selected = selectedConsole == console,
                        onClick = { selectedConsole = if (selectedConsole == console) null else console },
                        label = { Text(console) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(filtered, key = { it.id }) { game ->
                    GameCard(game, onClick = { onGameClick(game) })
                }
            }
        }
    }
}

@Composable
private fun GameCard(game: Game, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = coverPainter(game.cover),
                contentDescription = game.title,
                modifier = Modifier.width(80.dp).height(104.dp).clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text(game.title, style = MaterialTheme.typography.titleMedium)
                Text(game.releaseDate, style = MaterialTheme.typography.bodySmall)
                Text(game.genre, style = MaterialTheme.typography.bodySmall)
                Text(
                    game.consoles.joinToString(", "),
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
