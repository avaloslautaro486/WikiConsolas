package com.example.wikiconsolas

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.remember
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.wikiconsolas.data.GameRepository
import com.example.wikiconsolas.ui.DetailScreen
import com.example.wikiconsolas.ui.HomeScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                val games = remember { GameRepository.load(applicationContext) }
                val nav = rememberNavController()

                NavHost(navController = nav, startDestination = "home") {
                    composable("home") {
                        HomeScreen(games = games, onGameClick = { nav.navigate("detail/${it.id}") })
                    }
                    composable("detail/{id}") { entry ->
                        val game = games.first { it.id == entry.arguments?.getString("id") }
                        DetailScreen(game = game, onBack = { nav.popBackStack() })
                    }
                }
            }
        }
    }
}
